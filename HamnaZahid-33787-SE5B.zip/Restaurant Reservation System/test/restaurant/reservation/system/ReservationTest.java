/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant.reservation.system;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ABC
 */
public class ReservationTest {
    
    public ReservationTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of generateSchedule method, of class Reservation.
     */
    @Test
    public void testGenerateSchedule() {
        System.out.println("generateSchedule");
        Reservation instance = new Reservation();
        instance.generateSchedule();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of printSchedule method, of class Reservation.
     */
    @Test
    public void testPrintSchedule() {
        System.out.println("printSchedule");
        Reservation instance = new Reservation();
        instance.printSchedule();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of schedule method, of class Reservation.
     */
    @Test
    public void testSchedule() {
        System.out.println("schedule");
        int guests = 0;
        Reservation instance = new Reservation();
        instance.schedule(guests);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }
    
}
