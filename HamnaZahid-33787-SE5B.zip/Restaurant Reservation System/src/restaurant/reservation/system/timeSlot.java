/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant.reservation.system;
import java.util.*;
/**
 *
 * @author ABC
 */
public class timeSlot {
    
    private int start;
    private int end;
    public List<table> t;
  
   private boolean occupied;
   
   public timeSlot(int s, int e)
   {
       setStart(s);
       setEnd(e);
       t = new ArrayList<table>();
       
       for (int i =1; i<= 16; i++)
       {
           if (i < 5)
               t.add(new table ("small",2));
           else if( i < 17 )
            t.add(new table("extra large", 12) );
           else if(i < 16)
               t.add(new table ("large", 6));
           else if(i < 13)
               t.add(new table ("medium",4));
           
               
       }
     
   }
    
   public void setStart(int s)
   {
       if (s <= 21 && s >= 10)
          start = s; 
   }
   
   public void setEnd(int e)
   {
       if (e >= 11 && e <= 22)
        end = e;
   }
   
   public void setOccupied(boolean b)
   {
       occupied = b;
   }
   
   public boolean getOccupied()
   {
       return occupied;
   }
   
   public int getStart()
   {
       return start;
   }
   
   public int getEnd()
   {
       return end;
   }
}
