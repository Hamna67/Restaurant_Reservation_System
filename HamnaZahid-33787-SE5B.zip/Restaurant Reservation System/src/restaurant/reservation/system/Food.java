/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant.reservation.system;

/**
 *
 * @author ABC
 */
public class Food {
    
    private String type;
    private String name;
    private int time;
    private int number;
    
    public Food(String t, String n)
    {
        type = t;
        name = n;
        time = 30;
    }
    
    public void setNubmer(int n)
    {
        number = n;
    }
    
    public int getNumber()
    {
        return number;
    }
    
    public String getName()
    {
        return name;
    }
}
