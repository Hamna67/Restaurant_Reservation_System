/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant.reservation.system;

/**
 *
 * @author ABC
 */
public class table {
    
    private String name;
    private int size;
    
    private boolean occupied;
    
    public table(String n, int s)
    {
        name = n;
        size = s;
        setOccupied(false);
       
    }
    
    public void setOccupied(boolean b)
    {
        occupied = b;
    }
    
    public boolean getOccupied()
    {
        return occupied;
    }
    
    public int getSize()
    {
        return size;
    }
    
    public String getName()
    {
        return name;
    }
    
}
