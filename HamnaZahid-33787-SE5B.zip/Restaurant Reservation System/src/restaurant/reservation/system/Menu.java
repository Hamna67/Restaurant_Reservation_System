/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant.reservation.system;
import java.util.*;
/**
 *
 * @author ABC
 */
public class Menu {
    private Map map;
   
    public Menu()
    {
        map = new HashMap<String,Food>();
    }
    
    public void generateMenu()
    {
       
        map.put("Appetizer 1", new Food("Appetizer 1", "Appetizer 1"));
        map.put("Appetizer 2",new Food("Appetizer 2", "Appetizer 2"));
        map.put("Appetizer 3",new Food("Appetizer 3", "Appetizer 3"));
        map.put("Appetizer 4",new Food("Appetizer 4", "Appetizer 4"));
        map.put("Soup 1",new Food("Soup 1", "Soup 1"));
        map.put("Soup 2",new Food("Soup 2", "Soup 2"));
        map.put("Main course 1",new Food("Main course 1", "Main course 1"));
        map.put("Main course 2",new Food("Main course 2", "Main course 2"));
        map.put("Main course 3",new Food("Main course 3", "Main course 3"));
        map.put("Main course 4",new Food("Main course 4", "Main course 4"));
        map.put("Main course 5",new Food("Main course 5", "Main course 5"));
        map.put("Main course 6",new Food("Main course 6", "Main course 6"));
        map.put("Main course 7",new Food("Main course 7", "Main course 7"));
        map.put("Main course 8",new Food("Main course 8", "Main course 8"));
        map.put("Main course 9",new Food("Main course 9", "Main course 9"));
        map.put("Main course 10",new Food("Main course 10", "Main course 10"));
        map.put("Main course 11",new Food("Main course 11", "Main course 11"));
        map.put("Main course 12",new Food("Main course 12", "Main course 12"));
        map.put("Side dish 1",new Food("Side dish 1", "Side dish 1"));
        map.put("Side dish 2",new Food("Side dish 2", "Side dish 2"));
        map.put("Side dish 3",new Food("Side dish 3", "Side dish 3"));
        map.put("Desert 1",new Food("Desert 1", "Desert 1"));
        map.put("Desert 2",new Food("Desert 2", "Desert 2"));
        map.put("Desert 3",new Food("Desert 3", "Desert 3"));
        map.put("Desert 4",new Food("Desert 4", "Desert 4"));
   
        
    }
    
    public void print()
    {
      /*   Iterator it = map.entrySet().iterator();
    while (it.hasNext()) {
        Map.Entry pair = (Map.Entry)it.next();
        System.out.println(pair.getKey());
       // System.out.println(pair.getKey() + " = " + pair.getValue());
        it.remove(); // avoids a ConcurrentModificationException
    }*/
    
   
    for (Object value : map.values()) 
    {
        Food f = (Food)value;
        System.out.println(f.getName());
    }
    
    }
    
    
}
