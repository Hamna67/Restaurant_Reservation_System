/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant.reservation.system;
import java.util.Scanner;
/**
 *
 * @author ABC
 */
public class RestaurantReservationSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
   
       // Menu menu = new Menu();
        //menu.generateMenu();
        //menu.print();
        
        //taking input from user
        
       
        Reservation r = new Reservation();
        r.generateSchedule();
       
        
        Scanner sc = new Scanner(System.in);  
     
        System.out.println("Enter the number of guests:");  
        int guests = sc.nextInt();
        
        System.out.println(guests);
        
        r.schedule(guests);
      
        
         
         r.schedule(guests);
         r.schedule(guests);
         
          r.printSchedule();
    }
    
}
