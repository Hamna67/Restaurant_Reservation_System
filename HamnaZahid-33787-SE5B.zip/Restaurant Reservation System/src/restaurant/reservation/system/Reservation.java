/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant.reservation.system;
import java.util.*;
/**
 *
 * @author ABC
 */
public class Reservation {
    
    Map month;
    
    public Reservation()
    {
        month = new HashMap<Integer, List<timeSlot>>();
    }
    
    public void generateSchedule()
    {
        
        for (int i = 1; i < 31 ; i++)
        {
            List<timeSlot> l = new ArrayList<timeSlot>();
            
            for (int j = 11; j < 22 ; j++)
            {
                l.add(new timeSlot(j,j+1));
            }
            month.put(i,l);
        }
    }
    
    public void printSchedule()
    {
        for (int i = 1; i < 31 ; i++)
        {
            Iterator it = month.entrySet().iterator();
            while (it.hasNext()) 
            {
                Map.Entry pair = (Map.Entry)it.next();
                System.out.println(pair.getKey());
                List<timeSlot> l = (List<timeSlot>)pair.getValue();
                for (ListIterator<timeSlot> iter = l.listIterator(); iter.hasNext(); ) 
                {
                    timeSlot t = iter.next();
                    System.out.println("Start time:" + t.getStart() + "   End time: " + t.getEnd() + " Occupied: " + t.getOccupied());
                  //  it.remove(); // avoids a ConcurrentModificationException
                }
            }
                    
        }
    }
    
    public void schedule(int guests)
    {
        int hours = (int)guests / 8;
        int x = (int) guests % 8;
        boolean a = false;
        //System.out.println(x);
        
        Iterator it = month.entrySet().iterator();
            while (it.hasNext()) 
            {
                Map.Entry pair = (Map.Entry)it.next();
              //  System.out.println(pair.getKey());
                List<timeSlot> l = (List<timeSlot>)pair.getValue();
                for (ListIterator<timeSlot> iter = l.listIterator(); iter.hasNext(); ) 
                {
                    timeSlot t = iter.next();
                    List<table> ti = t.t;
                    for (ListIterator<table> i = ti.listIterator(); iter.hasNext();)
                    {
                        table tab = i.next();
                        if(guests <= tab.getSize())
                        {
                            if(!(tab.getOccupied()))
                            {
                                tab.setOccupied(true);
                                t.setOccupied(true);
                                a = true;
                                System.out.println("Booking from time: " + t.getStart() + ":00 to time: " + t.getEnd() + ":00 on day " + pair.getKey() + ", Occupied: " + t.getOccupied() + "    Table: " + tab.getName());
                                break;
                            }
                            
                        }
                        
                    }
                    if (a)
                        break;
                    //System.out.println("Start time:" + t.getStart() + "   End time: " + t.getEnd() + " Occupied: " + t.getOccupied());
                  //  it.remove(); // avoids a ConcurrentModificationException
                }
                 if (a)
                        break;
            }

    }
            
    
}
